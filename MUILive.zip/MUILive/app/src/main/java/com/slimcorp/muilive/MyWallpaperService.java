package com.slimcorp.muilive;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MyWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new MaterialEngine();
    }

    private class MaterialEngine extends Engine {
        private final Handler handler = new Handler();
        private final List<Shape> shapes = new ArrayList<>();
        private final Paint bgPaint = new Paint();
        private final Random random = new Random();
        private boolean visible = false;
        private long lastFrameTime;

        private float currentOffset = 0f;
        private float targetOffset = 0f;

        private final Runnable drawRunner = this::drawFrame;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            ShapeConfig config = ShapeConfig.load(MyWallpaperService.this);

            int bgColor, shapeColor;
            if (config.useDynamicColors) {
                ThemeColors theme = new ThemeColors(MyWallpaperService.this);
                bgColor = theme.primary;
                shapeColor = ThemeColors.lighten(theme.primary, 0.85f);
            } else {
                bgColor = ColorUtils.getDarkVariant(config.baseColor, 0.15f);
                shapeColor = ColorUtils.getLightVariant(config.baseColor, 0.85f);
            }

            bgPaint.setColor(bgColor);

            float screenWidth = getResources().getDisplayMetrics().widthPixels;
            float screenHeight = getResources().getDisplayMetrics().heightPixels;

            shapes.clear();

            Shape.Kind[] allKinds = {
                    Shape.Kind.FLOWER, Shape.Kind.CIRCLE, Shape.Kind.SQUIRCLE, Shape.Kind.HEXAGON
            };

            int cols = config.shapeCount;
            if (cols < 2) cols = 2;

            // Базовый размер ячейки
            float baseCellWidth = (screenWidth / cols) / config.scaleX;

            // Текущий размер фигуры (защита: не меньше 0.05)
            float currentSize = Math.max(0.05f, config.sizeMultiplier);
            float radius = baseCellWidth * currentSize;

            // Минимальный отступ (5% от базовой ячейки)
            float minGap = baseCellWidth * 0.05f;
            float cellWidth = (radius * 2) + minGap;

            // ЗАЩИТА ОТ ВЫЛЕТА:
            // Если фигура слишком маленькая (0.15), мы жестко ставим размер ячейки
            // равным базовому, чтобы сетка не "схлопнулась" и не было деления на ноль.
            if (cellWidth > baseCellWidth || cellWidth < 1f) {
                cellWidth = baseCellWidth;
            }

            // ЗАЩИТА: количество рядов не может быть бесконечным
            int rows = (int) Math.ceil(screenHeight / cellWidth) + 4;
            if (rows > 100) rows = 100; // Не даем циклу уйти в бесконечность

            for (int row = -2; row <= rows; row++) {
                for (int col = -2; col <= cols + 2; col++) {

                    float px = (col + 0.5f) * cellWidth;
                    float py = (row + 0.5f) * cellWidth;

                    if (row % 2 == 0) {
                        px += cellWidth * 0.5f;
                    }

                    float cx = (px / screenWidth);
                    float cy = (py / screenHeight);

                    Shape.Kind kind = allKinds[random.nextInt(allKinds.length)];
                    float rotationSpeed = (random.nextBoolean() ? 1 : -1) * config.rotationSpeed;
                    float petals = 6 + random.nextInt(4) * 2;

                    shapes.add(new Shape(kind, shapeColor, radius, cx, cy,
                            rotationSpeed, petals, config.petalDepth));
                }
            }
        }

        @Override
        public void onOffsetsChanged(float xOffset, float yOffset, float xOffsetStep, float yOffsetStep, int xPixelOffset, int yPixelOffset) {
            super.onOffsetsChanged(xOffset, yOffset, xOffsetStep, yOffsetStep, xPixelOffset, yPixelOffset);
            targetOffset = xOffset;
        }

        @Override
        public void onVisibilityChanged(boolean visible) {
            this.visible = visible;
            if (visible) {
                lastFrameTime = SystemClock.elapsedRealtime();
                drawFrame();
            } else {
                handler.removeCallbacks(drawRunner);
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            visible = false;
            handler.removeCallbacks(drawRunner);
        }

        private void drawFrame() {
            final SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    long now = SystemClock.elapsedRealtime();
                    float dt = (now - lastFrameTime) / 1000f;
                    lastFrameTime = now;
                    if (dt > 0.1f) dt = 0.1f;

                    currentOffset += (targetOffset - currentOffset) * 10f * dt;

                    canvas.drawColor(bgPaint.getColor());

                    canvas.save();
                    float shiftPixels = -currentOffset * canvas.getWidth() * 0.5f;
                    canvas.translate(shiftPixels, 0);

                    for (Shape s : shapes) {
                        s.update(dt);
                        s.draw(canvas);
                    }

                    canvas.restore();
                }
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }

            handler.removeCallbacks(drawRunner);
            if (visible) {
                handler.postDelayed(drawRunner, 33);
            }
        }
    }
}