package com.slimcorp.muilive;

import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

public class MainActivity extends AppCompatActivity {

    private ShapeConfig config;
    private MaterialSwitch switchDynamic;
    private LinearLayout layoutManualColors;
    private Slider sliderSpeed, sliderPetals, sliderSize;
    private MaterialButton btnApply;

    private final int[] availableColors = {
            0xFF6750A4, 0xFF3B82F6, 0xFF10B981, 0xFFF59E0B,
            0xFFF97316, 0xFFEF4444, 0xFFEC4899, 0xFF06B6D4
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        config = ShapeConfig.load(this);

        if (!config.useDynamicColors) {
            getWindow().setBackgroundDrawable(new ColorDrawable(ColorUtils.getDarkVariant(config.baseColor, 0.15f)));
        }

        setContentView(R.layout.activity_main);

        // Инициализация элементов
        switchDynamic = findViewById(R.id.switchDynamic);
        layoutManualColors = findViewById(R.id.layoutManualColors);
        sliderSpeed = findViewById(R.id.sliderSpeed);
        sliderPetals = findViewById(R.id.sliderPetals);
        sliderSize = findViewById(R.id.sliderSize);
        btnApply = findViewById(R.id.btnApply);

        // Загрузка значений
        switchDynamic.setChecked(config.useDynamicColors);
        sliderSpeed.setValue(config.rotationSpeed);
        sliderPetals.setValue(config.petalDepth);
        sliderSize.setValue(config.sizeMultiplier);

        // Настройка UI
        updateColorSectionVisibility();
        if (!config.useDynamicColors) {
            buildColorCircles();
            applyCustomThemeOverlay();
        }

        // Слушатели
        switchDynamic.setOnCheckedChangeListener((buttonView, isChecked) -> {
            config.useDynamicColors = isChecked;
            config.save(this);
            recreate();
        });

        sliderSpeed.addOnChangeListener((slider, value, fromUser) -> {
            config.rotationSpeed = value;
            config.save(this);
        });

        sliderPetals.addOnChangeListener((slider, value, fromUser) -> {
            config.petalDepth = value;
            config.save(this);
        });

        sliderSize.addOnChangeListener((slider, value, fromUser) -> {
            config.sizeMultiplier = value;
            config.save(this);
        });

        btnApply.setOnClickListener(v -> openWallpaperPicker());
    }

    private void applyCustomThemeOverlay() {
        int base = config.baseColor;

        int primary = ColorUtils.getDarkVariant(base, 0.15f);
        int cardColor = ColorUtils.getCardVariant(base);
        int textColor = ColorUtils.getTextColor(base);
        int accentColor = ColorUtils.getLightVariant(base, 0.85f);

        // Красим окно и системные панели
        getWindow().setBackgroundDrawable(new ColorDrawable(primary));
        getWindow().setStatusBarColor(primary);
        getWindow().setNavigationBarColor(primary);

        // Красим корневой ScrollView
        View rootScroll = findViewById(R.id.rootScrollView);
        if (rootScroll != null) {
            rootScroll.setBackgroundColor(primary);
        }

        // Красим карточки
        MaterialCardView cardPalette = findViewById(R.id.cardPalette);
        MaterialCardView cardAnimation = findViewById(R.id.cardAnimation);
        if (cardPalette != null) cardPalette.setCardBackgroundColor(cardColor);
        if (cardAnimation != null) cardAnimation.setCardBackgroundColor(cardColor);

        // Красим тексты
        tintAllTexts(findViewById(android.R.id.content), textColor);

        // Красим юзернейм и иконку
        android.widget.TextView username = findViewById(R.id.textUsername);
        if (username != null) username.setTextColor(accentColor);

        ImageView tiktokIcon = findViewById(R.id.tiktokIcon);
        if (tiktokIcon != null) {
            tiktokIcon.setImageTintList(ColorStateList.valueOf(accentColor));
        }

        // Красим кнопку
        if (btnApply != null) {
            btnApply.setBackgroundTintList(ColorStateList.valueOf(accentColor));
            btnApply.setTextColor(primary);
        }

        // Красим слайдеры
        if (sliderSpeed != null) {
            sliderSpeed.setTrackActiveTintList(ColorStateList.valueOf(accentColor));
            sliderSpeed.setThumbTintList(ColorStateList.valueOf(accentColor));
            sliderSpeed.setHaloTintList(ColorStateList.valueOf(accentColor).withAlpha(50));
        }
        if (sliderPetals != null) {
            sliderPetals.setTrackActiveTintList(ColorStateList.valueOf(accentColor));
            sliderPetals.setThumbTintList(ColorStateList.valueOf(accentColor));
            sliderPetals.setHaloTintList(ColorStateList.valueOf(accentColor).withAlpha(50));
        }
        if (sliderSize != null) {
            sliderSize.setTrackActiveTintList(ColorStateList.valueOf(accentColor));
            sliderSize.setThumbTintList(ColorStateList.valueOf(accentColor));
            sliderSize.setHaloTintList(ColorStateList.valueOf(accentColor).withAlpha(50));
        }

        // Красим переключатель
        if (switchDynamic != null) {
            switchDynamic.setThumbTintList(ColorStateList.valueOf(accentColor));
        }
    }

    private void tintAllTexts(View view, int color) {
        if (view instanceof android.widget.TextView) {
            if (!(view instanceof MaterialButton) && view.getId() != R.id.textUsername) {
                ((android.widget.TextView) view).setTextColor(color);
            }
        } else if (view instanceof android.view.ViewGroup) {
            android.view.ViewGroup group = (android.view.ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                tintAllTexts(group.getChildAt(i), color);
            }
        }
    }

    private void updateColorSectionVisibility() {
        layoutManualColors.setVisibility(config.useDynamicColors ? View.GONE : View.VISIBLE);
    }

    private void buildColorCircles() {
        layoutManualColors.removeAllViews();
        RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setOrientation(RadioGroup.HORIZONTAL);
        radioGroup.setGravity(Gravity.CENTER);

        for (int color : availableColors) {
            RadioButton rb = new RadioButton(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(90, 90);
            params.setMargins(8, 0, 8, 0);
            rb.setLayoutParams(params);

            GradientDrawable shape = new GradientDrawable();
            shape.setShape(GradientDrawable.OVAL);
            shape.setColor(color);

            if (color == config.baseColor) {
                shape.setStroke(6, Color.WHITE);
                rb.setChecked(true);
            } else {
                shape.setStroke(2, Color.LTGRAY);
            }

            rb.setBackground(shape);
            rb.setButtonDrawable(null);

            rb.setOnClickListener(v -> {
                config.baseColor = color;
                config.save(this);
                recreate();
            });

            radioGroup.addView(rb);
        }
        layoutManualColors.addView(radioGroup);
    }

    private void openWallpaperPicker() {
        try {
            // 1. Сбрасываем текущие обои (это заставит сервис перезапуститься)
            WallpaperManager wm = WallpaperManager.getInstance(this);
            // Вместо clear() (который ломает меню), просто ставим дефолтные обои
            wm.setResource(android.R.drawable.screen_background_dark);

        } catch (Exception e) {
            // Если не получилось сбросить, ничего страшного
        }

        try {
            // 2. Открываем меню выбора с принудительным Chooser
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, MyWallpaperService.class));

            // ВАЖНО: createChooser заставляет систему показать окно выбора (Главный / Оба)
            startActivity(Intent.createChooser(intent, "Выберите экран для обоев"));

        } catch (Exception e) {
            try {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            } catch (Exception ex) {
                Toast.makeText(this, "Не удалось открыть настройки обоев", Toast.LENGTH_SHORT).show();
            }
        }
    }
}