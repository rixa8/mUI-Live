package com.slimcorp.muilive;

import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;

public class Shape {
    public enum Kind { CIRCLE, SQUIRCLE, HEXAGON, FLOWER }

    private final Kind kind;
    private final int color;
    private final float radius;

    private float cx, cy;
    private final float rotationSpeed;
    private final float petals;
    private final float petalDepth;

    private float rotation = 0f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    public Shape(Kind kind, int color, float radius, float cx, float cy,
                 float rotationSpeed, float petals, float petalDepth) {
        this.kind = kind;
        this.color = color;
        this.radius = radius;
        this.cx = cx;
        this.cy = cy;
        this.rotationSpeed = rotationSpeed;
        this.petals = petals;
        this.petalDepth = petalDepth;

        paint.setColor(color);
        paint.setStyle(Paint.Style.FILL);
        paint.setPathEffect(new CornerPathEffect(radius * 0.2f));
    }

    public void update(float dt) {
        rotation += rotationSpeed * dt;
    }

    public void draw(Canvas canvas) {
        float w = canvas.getWidth();
        float h = canvas.getHeight();
        float x = cx * w;
        float y = cy * h;

        path.reset();
        buildPath(path, x, y, radius);

        canvas.save();
        canvas.rotate(rotation, x, y);
        canvas.drawPath(path, paint);
        canvas.restore();
    }

    private void buildPath(Path p, float x, float y, float r) {
        switch (kind) {
            case CIRCLE:
                p.addCircle(x, y, r, Path.Direction.CW);
                break;
            case SQUIRCLE: {
                float n = 4f;
                int steps = 120;
                for (int i = 0; i <= steps; i++) {
                    double t = 2 * Math.PI * i / steps;
                    float cosT = (float) Math.cos(t);
                    float sinT = (float) Math.sin(t);
                    float px = x + r * Math.signum(cosT) * (float) Math.pow(Math.abs(cosT), 2.0 / n);
                    float py = y + r * Math.signum(sinT) * (float) Math.pow(Math.abs(sinT), 2.0 / n);
                    if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
                }
                p.close();
                break;
            }
            case HEXAGON: {
                for (int i = 0; i < 6; i++) {
                    double angle = Math.PI / 6 + i * (Math.PI / 3);
                    float px = x + r * (float) Math.cos(angle);
                    float py = y + r * (float) Math.sin(angle);
                    if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
                }
                p.close();
                break;
            }
            case FLOWER: {
                int steps = 360;
                for (int i = 0; i <= steps; i++) {
                    double angle = 2 * Math.PI * i / steps;
                    float wave = (float) Math.cos(angle * petals);
                    float curR = r + (r * petalDepth * wave);
                    float px = x + curR * (float) Math.cos(angle);
                    float py = y + curR * (float) Math.sin(angle);
                    if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
                }
                p.close();
                break;
            }
        }
    }
}