package com.slimcorp.muilive;

import android.content.Context;
import android.content.SharedPreferences;

public class ShapeConfig {
    public boolean useDynamicColors = true;
    public float rotationSpeed = 1.4f;
    public float petalDepth = 0.15f;

    public int shapeCount = 2;
    public float scaleX = 0.70f;
    public float scaleY = 0.70f;
    public float sizeMultiplier = 0.30f;

    public int baseColor = 0xFF6750A4;

    private static final String PREFS = "material_shapes_prefs";

    public static ShapeConfig load(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        ShapeConfig c = new ShapeConfig();
        c.useDynamicColors = p.getBoolean("dynamic", true);
        c.rotationSpeed = p.getFloat("speed", 1.4f);
        c.petalDepth = p.getFloat("petals", 0.15f);
        c.sizeMultiplier = p.getFloat("size", 0.30f);
        c.baseColor = p.getInt("base_color", 0xFF6750A4);
        return c;
    }

    public void save(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("dynamic", useDynamicColors)
                .putFloat("speed", rotationSpeed)
                .putFloat("petals", petalDepth)
                .putFloat("size", sizeMultiplier)
                .putInt("base_color", baseColor)
                .apply();
    }
}